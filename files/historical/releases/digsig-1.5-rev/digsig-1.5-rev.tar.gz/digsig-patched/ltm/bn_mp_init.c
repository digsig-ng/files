/* LibTomMath, multiple-precision integer library -- Tom St Denis
 *
 * LibTomMath is a library that provides multiple-precision
 * integer arithmetic as well as number theoretic functionality.
 *
 * The library was designed directly after the MPI library by
 * Michael Fromberger but has been written from scratch with
 * additional optimizations in place.
 *
 * The library is free for all purposes without any express
 * guarantee it works.
 *
 * Tom St Denis, tomstdenis@iahu.ca, http://math.libtomcrypt.org
 *
 * Modifications :
 *   - 29 Sept 2003, A. Apvrille, <axelle.apvrille@ericsson.ca>
 *     porting to kernel 2.5.66: calloc --> kmalloc
 */
#include <tommath.h>
#include "../dsi.h"		/* AxL */

/* init a new bigint */
int mp_init(mp_int * a)
{
	/* allocate memory required and clear it */
	a->dp =
	    (mp_digit *) kmalloc(sizeof(mp_digit) * MP_PREC,
				 DIGSIG_SAFE_ALLOC);
	if (a->dp == NULL) {
		return MP_MEM;
	}
/*	memset(a->dp, 0x00, sizeof(mp_digit) * MP_PREC);*/

	/*a->dp = OPT_CAST calloc (sizeof (mp_digit), MP_PREC); */

	/* set the used to zero, allocated digits to the default precision
	 * and sign to positive */
	a->used = 0;
	a->alloc = MP_PREC;
	a->sign = MP_ZPOS;

	return MP_OKAY;
}
